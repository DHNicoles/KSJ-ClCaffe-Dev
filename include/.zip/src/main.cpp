#include "game/logic.h"
#include "utils/util.h"

ice::KernelAlg alg;
int main(int argc, char* argv[])
{
	////////////////////
	//parsing args
	////////////////////
	/*if (argc != 2)
	{
		LOG(ERROR) << "Usage : " << argv[0] << " your_cgf_file";
		return -1;
	}
	else
	{
		const char* cfg = argv[1];
		if (ice::parseCfg(cfg) != 0)
		{
			LOG(ERROR) << cfg << " file parse failed!";
			return -1;
		}
	}
	*/
	////////////////////
	//checking camera
	////////////////////
#if 0 

ice:VideoCapture cap;
	if (RETCODES_SUCCESS != cap.OnInit())
	{
		LOG(ERROR) << "Fatal : camera init failed";
		return -1;
	}
#else
	cv::VideoCapture cap(0);
	if (!cap.isOpened())
	{
		LOG(ERROR) << "Fatal : camera init failed";
		return -1;
	}
#endif

	////////////////////
	//start args
	////////////////////


	cv::Mat frame;
	cap >> frame;
	Stopwatch T_v;
	T_v.Reset();	T_v.Start();
	unsigned int offset = 0;
	while (!frame.empty())
	{
		ice::KernelAlg::Instance()->OnUpdate(frame, offset++);
		cv::imshow("camera-show", frame);
		cv::waitKey(1);
		cap >> frame;
	}
	return 0;
}
