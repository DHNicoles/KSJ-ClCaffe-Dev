#include "game/sync.h"
#include "game/object_info.h"
#include "utils/http_post.h"
namespace ice
{

	pthread_mutex_t Sync::g_mutex_continue_lock = PTHREAD_MUTEX_INITIALIZER;
	pthread_mutex_t Sync::g_mutex_buf_lock = PTHREAD_MUTEX_INITIALIZER;
	std::deque<ObjectInfo*> Sync::obj_ptr_buffer_;

	pthread_mutex_t Sync::g_mutex_cross_lock = PTHREAD_MUTEX_INITIALIZER;
	std::deque<vector<int> > Sync::cross_buffer_;
	volatile bool Sync::network_ok = true;


	void Sync::TakeToGetAgeGender(ObjectInfo* objPtr)
	{
		pthread_mutex_lock(&g_mutex_buf_lock);
		obj_ptr_buffer_.push_back(objPtr);
		LOG(INFO) << "[Http Post Thread] --in--Thread has obj_buffer size : " << obj_ptr_buffer_.size();
		pthread_mutex_unlock(&g_mutex_buf_lock);
	}

	void Sync::TakeCrossHumanInfo(int direct, int age, int gender)
	{
		std::vector<int> info = {direct, age, gender};

		pthread_mutex_lock(&g_mutex_cross_lock);
		cross_buffer_.push_back(info);
		LOG(INFO) << "info insert into cross_buffer size : " << cross_buffer_.size();
		pthread_mutex_unlock(&g_mutex_cross_lock);

	}

	bool Sync::CheckNetwork(const char* strUrl)
	{
		static std::string netstatus[2] = {"disconnected", "ok"};
		bool status = HttpPost::Instance()->CheckIsNetWorking(std::string(strUrl)); 
		LOG(INFO) << "check network status = " << netstatus[status];
		return status;
	}

	void Sync::StartPostThread()
	{
		//network detection
		network_ok = CheckNetwork("www.baidu.com");
		if(network_ok == false)
		{
			LOG(FATAL) << "Network Failed!";
			return;
		}
		//begin thread
		ThreadParam* tp = new ThreadParam(this);
		pthread_t id;
		g_continue = true;
		LOG(INFO) << "post thread start...";
		int ret = pthread_create(&id, NULL, PostThread, tp);
		if (ret) {
			LOG(FATAL) << "Create pthread error!";
			return;
		}
		//pthread_join(id, NULL);
		LOG(INFO) << "post thread start success";
	}

	void Sync::StopPostThread()
	{
		pthread_mutex_lock(&g_mutex_continue_lock);
		g_continue = false;
		pthread_mutex_unlock(&g_mutex_continue_lock);
	}

	void Sync::PostCrossHumanInfo(Sync* kap, const char* url, std::string& str)
	{
		/////////////////////////////////////////////////////////////////////////////////
		//send cross line human info to cloud
		//////////////////////////////////////////////////////////////////////////////////
		std::vector<int> info;
		pthread_mutex_lock(&g_mutex_cross_lock);
		if (!cross_buffer_.empty())
		{
			LOG(INFO) << "[Http Post Thread] cross buffer size : " << cross_buffer_.size();
			info.swap(cross_buffer_.front());
			cross_buffer_.pop_front();
		}
		pthread_mutex_unlock(&g_mutex_cross_lock);
		if(info.size() == 3)
		{

			static std::string prefix = "{\"token\":\"424d6f2e-25ed-43a8-894e-a33a6c977a57\", \"appId\":\"300005\"";
			std::string camerano_str = ",\"cameraNo\":\"" + std::to_string(g_camera_id);
			std::string storeid_str = "\",\"storeId\":\"" + std::to_string(g_store_id);
			std::string direct_str = "\",\"direction\":\"" + std::to_string(info[0]);
			std::string age_str = "\",\"age\":\"" + std::to_string(info[1]);
			std::string gender_str = "\",\"gender\":\"" + std::to_string(info[2]);
			std::string postfix = "\"}";
			std::string param = prefix + camerano_str + storeid_str + gender_str + age_str + direct_str + postfix;
			LOG(INFO) << "[Http Post Thread] param: " << param;
			int httpRet = kap->HttpConnectRef()->Post(url, param.c_str(), str);
			LOG(INFO) << "[Http Post Thread] retcode of crossline : " << httpRet;
			LOG(INFO) << "[Http Post Thread] return str : " << str;
		}

	}

	void Sync::PostAgeGender(Sync* kap, const char* url, std::string& str)
	{
		//////////////////////////////////////////////////////////////////////////////////
		//Age and Gender
		//get person headshot from buffer and post to http to get age & gender 
		//////////////////////////////////////////////////////////////////////////////////
		static CBase64Coder baseCoder;
		cv::Mat head;
		ObjectInfo* objPtr = NULL;
		pthread_mutex_lock(&g_mutex_buf_lock);
		if (!obj_ptr_buffer_.empty())
		{
			LOG(INFO) << "[Http Post Thread] ---pick obj---";
			objPtr = obj_ptr_buffer_.front();
			obj_ptr_buffer_.pop_front();
			head = objPtr->Head().clone();
			LOG(INFO) << "[Http Post Thread] ---get head--- ";
		}
		LOG(INFO) << "[Http Post Thread] --out--Thread has obj_buffer size : " << obj_ptr_buffer_.size();
		pthread_mutex_unlock(&g_mutex_buf_lock);
		if(objPtr)LOG(INFO) << "[Http Post Thread] Test person id: " << objPtr->index_
			<< ", head = NULL ? " << head.empty();
		else
			LOG(INFO) << "[Http Post Thread] Test objptr is NULL";
		//query age and gender
		if (!head.empty() && objPtr != NULL)
		{
			cv::Mat target;
			cv::resize(head, target, cv::Size(120, 150));
			const char* indexStr = "face";//std::to_string(objPtr->index_).c_str();
			std::vector<uchar> jpeg;
			cv::imencode(".jpg", target, jpeg);
			LOG(INFO) << "[Http Post Thread] show face";
			cv::imshow(indexStr, target);
			const char* encoded = baseCoder.encode((char*)jpeg.data(), jpeg.size());
			//LOG(INFO) << "base64: {" << encoded << "}";
			std::string prefix = "{\"token\":\"424d6f2e-25ed-43a8-894e-a33a6c977a57\", \"appId\":\"300005\", \"imgBase64\":\"";
			std::string postfix = "\"}";
			std::string param = prefix + encoded + postfix;
			LOG(INFO) << "[Http Post Thread] param: " << param.substr(0,100);
			std::string& json = str;
			int httpRet = 1;/*kap->HttpConnectRef()->Post(url, param.c_str(), str);
			std::string& json = str;
			LOG(INFO) << "[Http Post Thread] HttpPost func retcode of age&gender : " << httpRet;*/
			//parse
			if(httpRet == 0)// && false == json.empty())
			{
				//network_ok = true;
				json.erase(std::remove(json.begin(), json.end(), '\\'), json.end());
				LOG(INFO) << "[Http Post Thread] json: " << json;
				int d1 = json.find("dataValue") + 14;	
				std::string condstr = json.substr(d1);
				LOG(INFO) << "[Http Post Thread] condstr: " << condstr;
				bool success = condstr[0] != '}';
				LOG(INFO) << "[Http Post Thread] success: " << success;
				LOG(INFO) << "[Http Post Thread] over .person id: " << objPtr->index_;
				if(success)
				{
					//age
					std::string age_str = condstr.substr(condstr.find("age") + 6);
					age_str = age_str.substr(0, age_str.find("\""));
					int age_idx = atoi(age_str.c_str());
					//age_idx = age_idx > 7 ? 7 : age_idx;  
					LOG(INFO) << "[Http Post Thread] age: " << age_idx;
					//gender
					std::string gender_str = condstr.substr(condstr.find("gender") + 9);
					gender_str = gender_str.substr(0, gender_str.find("\""));
					int gender_idx = atoi(gender_str.c_str());
					//gender_idx = gender_idx > 1 ? 1 : gender_idx;  
					LOG(INFO) << "[Http Post Thread] gender: " << gender_idx;
					objPtr->GetSyncBack(success, age_idx, gender_idx);
					//save to dir
					std::string info = age_str + "_" + gender_str;

					LOG(INFO) << "[Http Post Thread] saving info " << info;
					//saveImageByIndex(target, objPtr->Index(), info);
				}
				else
				{
					objPtr->GetSyncBack(success, 1, 1);
				}
			}
			//something wrong with network 
			else
			{
				LOG(INFO) << "[Http Post Thread] json : " << json;
				LOG(INFO) << "[Http Post Thread] failed with network";
				objPtr->GetSyncBack(false, 2, 2);
			}
		}
		//something wrong with network 
		else
		{
			LOG(INFO) << "[Http Post Thread] obj_ptr is NULL : " << int(objPtr == NULL);
			LOG(INFO) << "[Http Post Thread] head is empty :" << head.empty();
		}
	}

	void* Sync::PostThread(void* param)
	{
		pthread_detach(pthread_self());
		ThreadParam* tp = (ThreadParam*)param;
		Sync* kap = tp->sync_ptr;
		delete tp;
		std::string result;
		const char* age_gender_url = "http://aismart.jd.com/smart/getGenderAge.action";
		const char* cross_url = "http://aismart.jd.com/smart/passengerStatistics.action";
		Stopwatch T0;
		while (g_continue)
		{
			T0.Reset();	T0.Start();
			//network detection
			/*network_ok = kap->CheckNetwork(age_gender_url);
			LOG(INFO) << "[Http Post Thread] network status: " << network_ok;
			if(network_ok == false)
			{
				sleep(1);
				continue;
			}*/


			//////////////////////////////////////////////////////////////////////////////////
			//send cross line human info to cloud
			//////////////////////////////////////////////////////////////////////////////////

			//PostCrossHumanInfo(kap, cross_url, result);

			//////////////////////////////////////////////////////////////////////////////////
			//Age and Gender
			//get person headshot from buffer and post to http to get age & gender 
			//////////////////////////////////////////////////////////////////////////////////

			PostAgeGender(kap, age_gender_url, result); 

			usleep(100000);
			T0.Stop();
			LOG(INFO) << "[Http Post Thread] cost " << T0.GetTime();
		}
		LOG(INFO) << "[Http Post Thread] thread exit.";

		return nullptr;
	}

	volatile bool Sync::g_continue = false;
	Sync::Sync() :
		http_ptr_(0)
	{

	}

	Sync::~Sync()
	{
		OnDestroy();
	}

	void Sync::OnInit()
	{
		http_ptr_ = new HttpPost();
		StartPostThread();
	}

	void Sync::OnDestroy()
	{
		StopPostThread();
		if (http_ptr_)
			delete http_ptr_;
		http_ptr_ = NULL;
	}

}
