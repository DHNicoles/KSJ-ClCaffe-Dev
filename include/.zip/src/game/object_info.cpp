#include "game/object_info.h"
#include "game/sync.h"
namespace ice
{

	//////////////////////////
	//age range
	//////////////////////////
	std::vector<std::string> ObjectInfo::ageRange =
	{
		"0~3", "4~7", "8~14", "15~24",
		"25~37", "38~47", "48~59", "60+", "?"
	};
	//////////////////////////
	//gender range
	//////////////////////////
	std::vector<std::string> ObjectInfo::genderTab = { "?", "male", "female" };

	ObjectInfo::ObjectInfo(int id, cv::Point point, cv::Rect& box) :
		trace_(1, point), newest_box_(box)
	{
		//time_vec[0] = getSystemTime();
		index_ = id;
		match_success_ = true;
		true_shit_ = false;
		life_ = l_life_begin;
		match_time_ = 0;
		decay_ = 1;
		max_score_ = 0;
		//count
		counted = false;
		
		//sync
		syncing_flag_ = false;

		age_ = 8;
		gender_ = 0;
	}
	void ObjectInfo::OnUpdate(cv::Mat& bound_mask, cv::Mat & frame)
	{
		if (this->true_shit_) return;
		cv::Point& center = Position();
		if (
				center.x < 0 ||
				center.y < 0 ||
				center.x >= bound_mask.cols ||
				center.y >= bound_mask.rows ||
				bound_mask.at<uchar>(center) == 0
		   )
		{
			true_shit_ = true;
		}
		else
		{
			//do sync
			SyncAgeGender(frame);
			if (match_success_)
			{
				life_ = life_ < l_life_begin ? l_life_begin : life_ + 1;
				max_score_ = max_score_ > life_ ? max_score_ : life_;
				decay_ = 1;
			}
			else
			{
				if (decay_ < 100) decay_ *= 1.1;
				life_ -= decay_;;
				//long time no match
				if (life_ <= 0) true_shit_ = true;
			}
		}
	}
	cv::Mat ObjectInfo::TakePicture(cv::Mat& frame)
	{
		static float scX = (float)frame.cols / g_detect_win.width;
		static float scY = (float)frame.rows / g_detect_win.height;
		float x = newest_box_.x * scX;
		float y = newest_box_.y * scY;
		float w = newest_box_.width * scX;
		float h = newest_box_.height * scY;
		cv::Rect headRoi = scaleRect(newest_box_, 1.5);
		return frame(headRoi & cv::Rect(0, 0, frame.cols, frame.rows)).clone();
	}

	//sync
	void ObjectInfo::SyncAgeGender(cv::Mat& frame)
	{
		//if first time to start or has got its synced result
		if (CanBeRecycle() && syncing_flag_== false)
		{
			head_ = TakePicture(frame);
			if(head_.empty()) return;
			Sync::TakeToGetAgeGender(this);	
			syncing_flag_ = true;
		}
	}

	void ObjectInfo::GetSyncBack(bool success, int age, int gender)
	{
		/*if(false == success)
		{
			age_ = 8;
        	        gender_ = 0;
		}			
		else
		{
			age_ = age;
			gender_ = gender;
		}	
		*/
		age_ = age;
		gender_ = gender;
		syncing_flag_ = false;
	}
	bool ObjectInfo::SynceOver()
	{
		return syncing_flag_ == false;
	}
	std::ostream& operator << (std::ostream& os, ObjectInfo & obj)
	{
		//os << "OBJ INFO: \nindex =\t\t" << obj.index_ << "\nstart time =\t" << obj.time_vec[0] << std::endl;
		//os << "end time =\t" << obj.time_vec[1] << std::endl;
		os << "Trace length =\t" << obj.GetTrace().size() << std::endl;
		os << "max_score =\t" << obj.MaxScore() << std::endl;
		return os;
	}

}
