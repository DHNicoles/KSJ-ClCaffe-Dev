#include "game/region.h"
#include "multi_tracker/multi_tracker.h"
#include "game/object_info.h"
namespace ice
{

	Region::Region()
	{
		left_clr_ = 0;
		right_clr_ = 255;
	}

	Region::~Region()
	{

	}

	int Region::OnInit(int width, int height)
	{
		mask_ = cv::Mat(cv::Size(width, height), CV_8UC1);
		cv::Rect left, right;
		if(g_count_direction == 1)//left to right
		{
			left = cv::Rect(0, 0, width / 2, height);
			right = cv::Rect(width / 2, 0, width / 2, height);
		}
		else if(g_count_direction == 2)//up to down
		{
			left = cv::Rect(0, 0, width, height / 2);
			right = cv::Rect(0, height / 2, width, height / 2);
		}
		mask_(left) = cv::Scalar::all(left_clr_);
		mask_(right) = cv::Scalar::all(right_clr_);

		count_mp_["left"] = 0;
		count_mp_["right"] = 0;
	}

	void Region::OnDestroy()
	{

	}

	void Region::OnUpdate(MultiTracker& multitracker)
	{
		std::map<size_t, ObjectInfo*>& tracking_obector_map = multitracker.TrackingObectorMap();
		std::map<size_t, ObjectInfo*>::iterator tom_it = tracking_obector_map.begin();
		std::map<size_t, ObjectInfo*>::iterator tom_end_it = tracking_obector_map.end();
		for (; tom_it != tom_end_it; ++tom_it)
		{
			int ret = GetPersonMotion(tom_it->second);
			if (ret == 1) count_mp_["left"]++;
			if (ret == 2) count_mp_["right"]++;
		}
	}

	size_t Region::LeftCrossNum()
	{
		return count_mp_["left"];
	}

	size_t Region::RightCrossNum()
	{
		return count_mp_["right"];
	}

	/////////////////////////
	///////0: no cross //////
	///////1: left cross<-///
	///////2: right cross->//
	/////////////////////////
	int Region::GetPersonMotion(ObjectInfo* obj_info)
	{
		if (
				obj_info->CrossLine() ||
				!obj_info->CanBeRecycle() ||
				obj_info->GetTrace().size() < 2
		   ) //no cross
			return 0;

		cv::Point cur_pos = obj_info->GetTrace().back();
		cv::Point pre_pos = obj_info->GetTrace().front();

		cur_pos.x = cur_pos.x < 0 ? 0 : cur_pos.x;
		cur_pos.y = cur_pos.y < 0 ? 0 : cur_pos.y;
		cur_pos.x = cur_pos.x > mask_.cols ? mask_.cols - 1 : cur_pos.x;
		cur_pos.y = cur_pos.y > mask_.rows ? mask_.rows - 1 : cur_pos.y;
		pre_pos.x = pre_pos.x < 0 ? 0 : pre_pos.x;
		pre_pos.y = pre_pos.y < 0 ? 0 : pre_pos.y;
		pre_pos.x = pre_pos.x > mask_.cols ? mask_.cols - 1 : pre_pos.x;
		pre_pos.y = pre_pos.y > mask_.rows ? mask_.rows - 1 : pre_pos.y;

		int cur_clr = mask_.at<uchar>(cur_pos);
		int pre_clr = mask_.at<uchar>(pre_pos);
		if (cur_clr == pre_clr) 
		{
			return 0;
		}
		else if (pre_clr == right_clr_ && cur_clr == left_clr_)
		{
			//<<----
			obj_info->CrossLine() = true;
			
			return 1;
		}
		else if (pre_clr == left_clr_ && cur_clr == right_clr_)
		{
			//---->>
			obj_info->CrossLine() = true;
			return 2;
		}
	}

}
