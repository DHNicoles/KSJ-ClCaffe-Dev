#include "game/logic.h"
#include "game/object_info.h"
#include "detector/detector.h"
#include "game/region.h"
#include "game/sync.h"
namespace ice
{
	////////////////////////////////////
	//local def
	////////////////////////////////////
	double l_iou_thresh = 0.3;

	KernelAlg::KernelAlg() :
		detector_ptr_(NULL), Inited(false), region_ptr_(NULL), sync_ptr_(NULL)
	{
		OnInit();
		cv::Rect bound(g_margin, g_margin,
			g_detect_win.width - 2 * g_margin, g_detect_win.height - 2 * g_margin);
		//set detector_win, trackor_win
		SetBound(g_detect_win, bound);
	}

	KernelAlg::~KernelAlg()
	{
		OnDestroy();
		Inited = false;
	}

	void KernelAlg::OnInit()
	{
		detector_ptr_ = new Detector;
		detector_ptr_->OnInit();

		region_ptr_ = new Region;
		region_ptr_->OnInit(g_detect_win.width, g_detect_win.height);

		multi_trackers_ptr_ = new MultiTracker;
		multi_trackers_ptr_->OnInit();

		sync_ptr_ = new Sync();
		sync_ptr_ -> OnInit();
		Inited = true;
	}
	void KernelAlg::OnDestroy()
	{
		if (detector_ptr_)
		{
			delete detector_ptr_;
		}
		detector_ptr_ = NULL;

		if (multi_trackers_ptr_)
		{
			delete multi_trackers_ptr_;
		}
		multi_trackers_ptr_ = NULL;

		if (region_ptr_)
		{
			delete region_ptr_;
		}
		region_ptr_ = NULL;

		if (sync_ptr_)
		{
			delete sync_ptr_;
		}
		sync_ptr_ = NULL;
		//////////////////////////////////////////////////////////////////////////
	}

	void KernelAlg::OnUpdate(cv::Mat& frame, size_t offset)
	{
		cv::Mat crop_frame;
		cv::resize(frame, crop_frame, g_detect_win);

		//Timer
		static Stopwatch timer;
		timer.Reset();	timer.Start();
		/////////////////////////////////////////////////////////
		//trackers updating
		MultiTracker::Instance()->OnUpdate(crop_frame);
		MultiTracker::Instance()->RemoveInvalid();

		timer.Stop();
		LOG(INFO) << "update trackers\t=\t" << timer.GetTime();
		/////////////////////////////////////////////////////////
		//detector updating
		std::vector<cv::Rect> obj_boxes, scaled_box;
		std::vector<float> score;
		timer.Reset();	timer.Start();
		//Note : input size = l_windows size
		Detector::Instance()->Detect(crop_frame, obj_boxes, score);

		timer.Stop();
		LOG(INFO) << "detector num\t=\t" << obj_boxes.size();
		LOG(INFO) << "detector cost\t=\t" << timer.GetTime();

		//////////////////////////////////////////////////////////////////////////
		//matcher
		Match_ex(obj_boxes, crop_frame);
		//update object information
		MultiTracker::Instance()->UpdateObjInfo(frame);
		//update region counting
		Region::Instance()->OnUpdate(*MultiTracker::Instance());

		//////////////////////////////////////////////////////////////////////////
		//DRAW_DETECTOR
		if (false)
		{
			for (size_t i = 0; i < obj_boxes.size(); ++i)
			{
				cv::rectangle(crop_frame, obj_boxes[i], cv::Scalar(255, 255, 255), 2, 1, 0);
			}
		}
		//DRAW_TRACKER
		if (true)
		{
			MultiTracker::Instance()->DrawUI(frame);
			std::string time_str = getSystemTime();
			cv::putText(frame, time_str.c_str(), cv::Point(0, 14), 1, 1, CV_RGB(25, 255, 215), 1);
		}
		//DRAW_COUNTER
		if (true)
		{
			size_t left_num = Region::Instance()->LeftCrossNum();
			size_t right_num = Region::Instance()->RightCrossNum();
			std::string info = "        left cross num = ";
			info += std::to_string(left_num);
			info += "             right cross num = ";
			info += std::to_string(right_num);

			if (g_count_direction == 1)
			{
				cv::line(frame, cv::Point(frame.cols / 2, 0), cv::Point(frame.cols / 2, frame.rows - 1), CV_RGB(0, 0, 0), 3);
			}
			else if (g_count_direction == 2)
			{
				cv::line(frame, cv::Point(0, frame.rows / 2), cv::Point(frame.cols - 1, frame.rows / 2), CV_RGB(0, 0, 0), 3);
			}
			cv::Rect banner(0, 0, frame.cols, 20);
			frame(banner) = cv::Scalar(255, 0, 0);
			cv::putText(frame, info.c_str(), cv::Point(0, 14), 1, 1, CV_RGB(25, 255, 215), 1);
		}

	}
	void KernelAlg::SetBound(cv::Size size, cv::Rect r)
	{
		MultiTracker::Instance()->SetBound(size, r);
	}

	void KernelAlg::PrintRecycle()
	{
		//multi_trackers_.PrintRecycle();
	}



	void KernelAlg::Match(std::vector<cv::Rect>& detect_boxes, cv::Mat& frame)
	{

		MultiTracker::Instance()->SetAllMatchFalse();

		std::map<size_t, ObjectInfo*>& tracking_obector_map = MultiTracker::Instance()->TrackingObectorMap();

		for (size_t i = 0; i < detect_boxes.size(); ++i)
		{
			std::map<size_t, ObjectInfo*>::iterator tom_it = tracking_obector_map.begin();
			std::map<size_t, ObjectInfo*>::iterator tom_end_it = tracking_obector_map.end();
			std::map<size_t, ObjectInfo*>::iterator closest_it = tom_end_it;
			int min_dist = 1000000;

			for (; tom_it != tom_end_it; ++tom_it)
			{
				int dist = distanceOfCentroid(detect_boxes[i], tom_it->second->Position());
				if (dist < min_dist && dist < DIST_HUMAN)
				{
					min_dist = dist;
					closest_it = tom_it;
				}
			}
			if (closest_it == tom_end_it)
			{
				LOG(INFO) << "add to tracker";
				MultiTracker::Instance()->AddTracker(frame, detect_boxes[i]);
			}
			else
			{
				MultiTracker::Instance()->SetMatchTrue(closest_it->first);
				cv::Rect iou = (closest_it->second->Box() & detect_boxes[i]);
				cv::Rect un = (closest_it->second->Box() | detect_boxes[i]);
				double t = (double)iou.area() / un.area();
				if (t < 0.9)
				{
					LOG(INFO) << "replace tracker.index = " << closest_it->first;
					MultiTracker::Instance()->Replace(frame, detect_boxes[i], closest_it->first);
				}
			}
		}
	}
	void KernelAlg::Match_ex(std::vector<cv::Rect>& detect_boxes, cv::Mat& frame)
	{

		MultiTracker::Instance()->SetAllMatchFalse();

		std::map<size_t, ObjectInfo*>& tracking_objector_map = MultiTracker::Instance()->TrackingObectorMap();

		for (int i = 0; i < detect_boxes.size(); ++i)
		{
			std::map<size_t, ObjectInfo*>::iterator tom_it = tracking_objector_map.begin();
			std::map<size_t, ObjectInfo*>::iterator tom_end_it = tracking_objector_map.end();
			std::map<size_t, ObjectInfo*>::iterator closest_iter = tracking_objector_map.end();
			double max_iou = l_iou_thresh;//0.3
			//searching for the most closest one in tracker boxes
			for (; tom_it != tom_end_it; ++tom_it)
			{
				double iou = distanceOfIOU(detect_boxes[i], tom_it->second->Box());
				if (iou > max_iou)
				{
					max_iou = iou;
					closest_iter = tom_it;
				}
			}

			//if there's no one was found
			if (closest_iter == tom_end_it)
			{
				LOG(INFO) << "add to tracker";
				MultiTracker::Instance()->AddTracker(frame, detect_boxes[i]);
			}
			//else, check if the closest box is more suitable
			else
			{
				MultiTracker::Instance()->SetMatchTrue(closest_iter->first);
				if (max_iou < 0.8)
				{
					LOG(INFO) << "replace tracker.id = " << closest_iter->first;
					MultiTracker::Instance()->Replace(frame, detect_boxes[i], closest_iter->first);
				}
			}
		}
	}
}
