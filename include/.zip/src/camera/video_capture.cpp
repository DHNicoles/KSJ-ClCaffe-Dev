#include "camera/video_capture.h"

namespace ice
{
	LONG VideoCapture::lPlayPort = 0;
	LONG VideoCapture::lRealPlayHandle;
	LONG VideoCapture::lUserID;
	int VideoCapture::dwSize = 0;
	VideoCapture::VideoCapture()
	{

	}

	VideoCapture::~VideoCapture()
	{
		OnDestroy();
	}

	int VideoCapture::OnInit()
	{
		if (!NET_DVR_Init()) {
			LOG(ERROR) << "init hik-sdk error";
			return RETCODES_INIT_ERROR;
		}
		//设置连接时间与重连时间
		NET_DVR_SetConnectTime(2000, 1);
		NET_DVR_SetReconnect(10000, true);

		//---------------------------------------
		//设置异常消息回调函数
		NET_DVR_SetExceptionCallBack_V30(0, NULL, g_ExceptionCallBack, NULL);
		//登录参数，包括设备地址、登录用户、密码等
		//std::string ip = g_camera_ip;
		std::string ip = "192.168.1.200";
		int port = 8000;
		std::string user = "admin";
		std::string password = "123456abc";
		LOG(INFO) << "ip= " << ip << ", port= " << port << ", user= " << user << ", password= " << password;

		if (ip == "" || port <= 0 || user == "" || password == "") {
			LOG(ERROR) << "invalid parameter:" + ip + user + password;
			return RETCODES_INIT_ERROR;
		}
		//---------------------------------------
		// 注册设备

		NET_DVR_USER_LOGIN_INFO struLoginInfo = { 0 };
		struLoginInfo.bUseAsynLogin = 0; //同步登录方式
		strcpy(struLoginInfo.sDeviceAddress, ip.c_str()); //设备IP地址
		struLoginInfo.wPort = port; //设备服务端口
		strcpy(struLoginInfo.sUserName, user.c_str()); //设备登录用户名
		strcpy(struLoginInfo.sPassword, password.c_str()); //设备登录密码

		//设备信息, 输出参数
		NET_DVR_DEVICEINFO_V40 struDeviceInfoV40 = { 0 };

		lUserID = NET_DVR_Login_V40(&struLoginInfo, &struDeviceInfoV40);
		if (lUserID < 0) {
			printf("Login failed, error code: %d\n", NET_DVR_GetLastError());
			NET_DVR_Cleanup();
			return RETCODES_INIT_ERROR;
		}

		//---------------------------------------
		//启动预览并设置回调数据流


		NET_DVR_PREVIEWINFO struPlayInfo = { 0 };
		struPlayInfo.hPlayWnd = NULL;         //需要SDK解码时句柄设为有效值，仅取流不解码时可设为空
		struPlayInfo.lChannel = 1;       //预览通道号
		struPlayInfo.dwStreamType = 0;       //0-主码流，1-子码流，2-码流3，3-码流4，以此类推
		struPlayInfo.dwLinkMode = 0;       //0- TCP方式，1- UDP方式，2- 多播方式，3- RTP方式，4-RTP/RTSP，5-RSTP/HTTP
		struPlayInfo.bBlocked = 1;       //0- 非阻塞取流，1- 阻塞取流

		lRealPlayHandle = NET_DVR_RealPlay_V40(lUserID, &struPlayInfo, g_RealDataCallBack_V30, NULL);
		if (lRealPlayHandle < 0) {
			LOG(ERROR) << "NET_DVR_RealPlay_V40 error, " << NET_DVR_GetLastError();
			NET_DVR_Logout(lUserID);
			NET_DVR_Cleanup();
			return RETCODES_INIT_ERROR;
		}
		sleep(1);

		//获取当前视频文件的分辨率
		int dwWidth = 0;
		int dwHeight = 0;
		int bFlag = PlayM4_GetPictureSize(lPlayPort, &dwWidth, &dwHeight);
		dwSize = dwWidth * dwHeight;
		LOG(INFO) << "dwSize=" << dwSize;

		return RETCODES_SUCCESS;
	}

	void VideoCapture::OnDestroy()
	{
		//---------------------------------------
		//关闭预览

		NET_DVR_StopRealPlay(lRealPlayHandle);

		//释放播放库资源
		PlayM4_Stop(lPlayPort);
		PlayM4_CloseStream(lPlayPort);
		PlayM4_FreePort(lPlayPort);

		//注销用户
		NET_DVR_Logout(lUserID);
		NET_DVR_Cleanup();
	}

	cv::Mat VideoCapture::Query()
	{
		unsigned int capSize = 0;
		BYTE *jPic = new BYTE[dwSize * 5];
		int bFlag = PlayM4_GetJPEG(lPlayPort, jPic, dwSize, &capSize);
		if (bFlag == FALSE)
		{
			LOG(ERROR) << "get bmp pic error, code=" << PlayM4_GetLastError(lPlayPort);
			return cv::Mat();
		}
		std::vector<BYTE>vec(jPic, jPic + capSize);
		delete jPic;
		return cv::imdecode(vec, 1);
	}
	VideoCapture& VideoCapture::operator>>(cv::Mat& src)
	{
		src = Query();
		return *this;
	}
	void VideoCapture::g_RealDataCallBack_V30(LONG lRealHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, void *dwUser) {
		switch (dwDataType) {
		case NET_DVR_SYSHEAD: //系统头

			if (!PlayM4_GetPort(&lPlayPort))  //获取播放库未使用的通道号
			{
				LOG(ERROR) << "get port error";
				break;
			}
			//m_iPort = lPort; //第一次回调的是系统头，将获取的播放库port号赋值给全局port，下次回调数据时即使用此port号播放
			if (dwBufSize > 0) {
				if (!PlayM4_SetStreamOpenMode(lPlayPort, STREAME_REALTIME))  //设置实时流播放模式
				{
					LOG(ERROR) << "set stream mode error, code=" << PlayM4_GetLastError(lPlayPort);
					break;
				}

				if (!PlayM4_OpenStream(lPlayPort, pBuffer, dwBufSize, 1024 * 1024)) //打开流接口
				{
					LOG(ERROR) << "open stream error, code=" << PlayM4_GetLastError(lPlayPort);
					break;
				}

				if (!PlayM4_Play(lPlayPort, NULL)) //播放开始
				{
					LOG(ERROR) << "play error, code=" << PlayM4_GetLastError(lPlayPort);
					break;
				}
				LOG(INFO) << "play success";

			}
			break;
		case NET_DVR_STREAMDATA:   //码流数据
			if (dwBufSize > 0) {
				if (!PlayM4_InputData(lPlayPort, pBuffer, dwBufSize)) {
					LOG(ERROR) << "input data error, code=" << PlayM4_GetLastError(lPlayPort);
					break;
				}
			}
			break;
		default: //其他数据
			//            LOG(INFO)<<"other data";
			if (dwBufSize > 0) {
				if (!PlayM4_InputData(lPlayPort, pBuffer, dwBufSize)) {
					LOG(ERROR) << "input other data error, code=" << lPlayPort;
					break;
				}
			}
			break;
		}
	}

	void VideoCapture::g_ExceptionCallBack(DWORD dwType, LONG lUserID, LONG lHandle, void *pUser) {
		char tempbuf[256] = { 0 };
		switch (dwType) {
			case
			EXCEPTION_RECONNECT:    //预览时重连
				LOG(ERROR) << "----------reconnect--------" << time(NULL);
				break;
			default:
				break;
		}
	}
}
