#include "utils/http_post.h"
namespace ice
{

	HttpPost::HttpPost()
	{

	}

	HttpPost::~HttpPost()
	{

	}
	

	int HttpPost::OnInit()
	{
		
		
	}

	void HttpPost::OnDestory()
	{

	}

	size_t HttpPost::write_data(void *ptr, size_t size, size_t nmemb, void * data)
	{
		size_t sz = size * nmemb;
		struct MemoryStruct * mem = (struct MemoryStruct *) data;
		mem->memory = (char *)realloc(mem->memory, mem->size + sz + 1);

		if (mem->memory == NULL) 
		{
			/* out of memory! */
			LOG(ERROR) << "not enough memory (realloc returned NULL)";
			return 0;
		}
		memcpy(&(mem->memory[mem->size]), ptr, sz);
		mem->size += sz;
		mem->memory[mem->size] = 0;
		return sz;
	}

	bool HttpPost::CheckIsNetWorking(std::string url)
	{
		//��curl��
		CURL *curl;
		//��curlcode��
		CURLcode res;

		curl = curl_easy_init();
		if(curl) {
			//����������
			curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
			//������,������res
			res = curl_easy_perform(curl);
			//res=0����������,���������
			if(res!=0)
			{
				//����
				return false;
			}
			else
			{
				//����
				return true;

			}
			/* ���� */
			curl_easy_cleanup(curl);
		}
		return false; 
	}
	

	int HttpPost::Post(std::string url, const char* data, std::string& result)
	{
		struct MemoryStruct chunk;
		chunk.memory = (char *)malloc(1);  // will be grown as needed by the realloc above 
		chunk.size = 0;
		CURL* curl_ = curl_easy_init();
		
		struct curl_slist *list = NULL;
		list = curl_slist_append(list, "Expect: ");
		
		curl_easy_setopt(curl_, CURLOPT_HTTPHEADER, list);
		curl_easy_setopt(curl_, CURLOPT_URL, url);
		curl_easy_setopt(curl_, CURLOPT_POSTFIELDS, data);
		curl_easy_setopt(curl_, CURLOPT_WRITEFUNCTION, write_data);
		curl_easy_setopt(curl_, CURLOPT_WRITEDATA, &chunk);
		curl_easy_setopt(curl_, CURLOPT_POST, 1);
		curl_easy_setopt(curl_, CURLOPT_VERBOSE, 1);
		curl_easy_setopt(curl_, CURLOPT_HEADER, 1);
		curl_easy_setopt(curl_, CURLOPT_FOLLOWLOCATION, 1);
		curl_easy_setopt(curl_, CURLOPT_COOKIEFILE, "/export/cheguangfu/flowhooper_curlpost.cookie");
		curl_easy_setopt(curl_, CURLOPT_TIMEOUT, 3);
		CURLcode res = curl_easy_perform(curl_);
		curl_slist_free_all(list); 
		int retCode = 0;
		if (CURLE_OK != res)
		{
			LOG(ERROR) << "url Post failed, error code : " << res << std::endl;
			retCode = 1;
		}
		else
		{
			result.assign(chunk.memory, chunk.memory + chunk.size);
		}

		free(chunk.memory);
		curl_easy_cleanup(curl_);
		return retCode;
	}

}
