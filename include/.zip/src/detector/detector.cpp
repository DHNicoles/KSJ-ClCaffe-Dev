#include "detector/detector.h"
#include "detector/ssd_net.h"

namespace ice
{

	Detector::Detector()
		:ssd_net_ptr_(NULL)
	{
	}

	Detector::~Detector()
	{
		Destroy();
	}

	void Detector::OnInit()
	{
		/////////////////////////////////////////////////
		//Use DETECTOR_TYPE_MTCNN or DETECTOR_TYPE_SSD
		//detector_type = DETECTOR_TYPE_MTCNN;
		detector_type = DETECTOR_TYPE_SSD;
		/////////////////////////////////////////////////

		//ssd-net init
		/////////////////////////////////////////////////
		std::string model = "../../resource/model/wanda/fused_MobileNetSSD_deploy.prototxt";
		std::string weights = "../../resource/model/wanda/fused_MobileNetSSD_deploy.caffemodel";
		ssd_net_ptr_ = new SSDNet;
		ssd_net_ptr_->OnInit(model, weights);
		//mtcnn init
		mt_ptr_ = new mtcnn(512, 512);
	}

	void Detector::Destroy()
	{
		if (ssd_net_ptr_)
			delete ssd_net_ptr_;
		ssd_net_ptr_ = NULL;

		if (mt_ptr_)
			delete mt_ptr_;
		mt_ptr_ = NULL;
	}

	void Detector::Detect(cv::Mat& src, std::vector<cv::Rect>& targets, std::vector<float>& score)
	{
		if (src.empty())
		{
			LOG(ERROR) << "detector a empty frame. skip";
			return;
		}
		if (detector_type == DETECTOR_TYPE_SSD)
		{
			ssd_net_ptr_->Detect(src, targets, score);
		}
		else if (detector_type == DETECTOR_TYPE_MTCNN)
		{
			targets = mt_ptr_->detectObject(src);
		}
	}
}
