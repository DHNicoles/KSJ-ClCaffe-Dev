#include "multi_tracker.h"
#include "kcftracker.hpp"
#include "../game/object_info.h"
namespace ice
{
	MultiTracker::MultiTracker() :
		key_max_(0)
	{
		OnInit();
	}
	MultiTracker::~MultiTracker()
	{
		OnDestroy();
	}
	void MultiTracker::OnInit()
	{

	}
	void MultiTracker::OnDestroy()
	{
		//delete kcf_trakers
		std::map<size_t, KCFTracker*>::iterator tracker_itr = traker_map_.begin();
		std::map<size_t, KCFTracker*>::iterator tracker_end_itr = traker_map_.end();
		for (; tracker_itr != tracker_end_itr; ++tracker_itr)
		{
			if (tracker_itr->second)
				delete tracker_itr->second;
			tracker_itr->second = NULL;
		}
		//delete object
		std::map<size_t, ObjectInfo*>::iterator obj_itr = object_info_map_.begin();
		std::map<size_t, ObjectInfo*>::iterator obj_end_itr = object_info_map_.end();
		for (; obj_itr != obj_end_itr; ++obj_itr)
		{
			if (obj_itr->second)
				delete obj_itr->second;
			obj_itr->second = NULL;
		}
	}
	void MultiTracker::AddTracker(cv::Mat & frame, cv::Rect & positionBox)
	{
		int index = GetIndex_();
		//LOG(INFO) << "add tracker GetIndex_=" << index;
		KCFTracker* tracker_ptr = new KCFTracker(HOG_, FIXEDWINDOW_, MULTISCALE_, LAB_, index);
		positionBox &= cv::Rect(0, 0, frame.cols, frame.rows);
		tracker_ptr->init(positionBox, frame);
		int cent_x = positionBox.x + (positionBox.width >> 1);
		int cent_y = positionBox.y + (positionBox.height >> 1);
		traker_map_[index] = tracker_ptr;
		object_info_map_[index] = new ObjectInfo(index, cv::Point(cent_x, cent_y), positionBox);
	}
	void MultiTracker::OnUpdate(cv::Mat & frame)
	{
		//update kcf_trakers and object information
		std::map<size_t, KCFTracker*>::iterator tracker_itr = traker_map_.begin();
		std::map<size_t, KCFTracker*>::iterator tracker_end_itr = traker_map_.end();
		for (; tracker_itr != tracker_end_itr; ++tracker_itr)
		{
			cv::Rect pos = tracker_itr->second->update(frame);
			int cent_x = pos.x + (pos.width >> 1);
			int cent_y = pos.y + (pos.height >> 1);
			object_info_map_[tracker_itr->first]->GetTrace().push_back(cv::Point(cent_x, cent_y));
			object_info_map_[tracker_itr->first]->Box() = pos;
			//object_info_map_[tracker_itr->first]->SetSafety(true);
		}
		//clear objects when Iou > thresh by obj's Life
		std::map<size_t, ObjectInfo*>::iterator obj_itr = object_info_map_.begin();
		std::map<size_t, ObjectInfo*>::iterator obj_end_itr = object_info_map_.end();
		for (; obj_itr != obj_end_itr; ++obj_itr)
		{
			if(obj_itr->second->IsShit() == true) continue;
			std::map<size_t, ObjectInfo*>::iterator obj_j = obj_itr;
			++obj_j;
			for (; obj_j != obj_end_itr; ++obj_j)
			{
				cv::Rect in = (obj_itr->second->Box() & obj_j->second->Box());
				//cv::Rect un = (obj_itr->second->Box() | obj_j->second->Box());
				float t = max((float)in.area() / obj_itr->second->Box().area(), (float)in.area() / obj_j->second->Box().area());
				if (t > 0.8)
				{
					//the area bigger one  of them should be shit
					//obj_itr->second->IsShit() = true;
					//obj_j->second->IsShit() = true;
					if(obj_itr->second->Box().area() < obj_j->second->Box().area())
					{
						obj_itr->second->IsShit() = true;
					}
					else
					{
						obj_j->second->IsShit() = true;
					}
				}
			}

		}
	}

	void MultiTracker::UpdateObjInfo(cv::Mat & frame)
	{
		std::map<size_t, ObjectInfo*>::iterator obj_itr = object_info_map_.begin();
		std::map<size_t, ObjectInfo*>::iterator obj_end_itr = object_info_map_.end();
		for (; obj_itr != obj_end_itr; ++obj_itr)
		{
			obj_itr->second->OnUpdate(bound_mask_, frame);
		}
	}

	void MultiTracker::Mark(size_t index)
	{

	}
	void MultiTracker::RemoveInvalid()
	{
		//search invalid object's index
		std::map<size_t, ObjectInfo*>::iterator obj_itr = object_info_map_.begin();
		std::map<size_t, ObjectInfo*>::iterator obj_end_itr = object_info_map_.end();
		for (; obj_itr != obj_end_itr; ++obj_itr)
		{
			if (obj_itr->second->IsShit())
				invalid_index_list_.push_back(obj_itr->first);
		}
		//move invalid object to recycle by index
		std::list<size_t>::iterator iil_it = invalid_index_list_.begin();
		std::list<size_t>::iterator iil_end_it = invalid_index_list_.end();
		for (; iil_it != iil_end_it; ++iil_it)
		{
			size_t idx = *iil_it;
			//LOG(INFO) << "remove tracker index : " << idx;
			RemoveTrackerByIndex_(idx);
			//index_pool_set_.insert(idx);
		}
		invalid_index_list_.clear();

		//clear recycle
		std::map<size_t, ObjectInfo*>::iterator ryc_itr = recycle_object_info_map_.begin();
		std::map<size_t, ObjectInfo*>::iterator ryc_end_itr = recycle_object_info_map_.end();
		for (; ryc_itr != recycle_object_info_map_.end();)
		{
			if (ryc_itr->second->SynceOver())
			{
				//LOG(INFO) << "clear recycle id : "<< ryc_itr->first;
				delete ryc_itr->second;
				ryc_itr = recycle_object_info_map_.erase(ryc_itr);
			}
			else
			{
				//LOG(INFO) << "syncing recycle id : "<< ryc_itr->first;
				++ryc_itr;
			}
		}
		LOG(INFO) << "recycle still has " << recycle_object_info_map_.size() << " to be clean.";
	}
	void MultiTracker::RemoveTrackerByIndex_(size_t index)
	{
		std::map<size_t, KCFTracker*>::iterator tracker_itr = traker_map_.find(index);
		std::map<size_t, ObjectInfo*>::iterator obj_itr = object_info_map_.find(index);
		if (tracker_itr != traker_map_.end() && obj_itr != object_info_map_.end())
		{
			//obj_itr->second->SetEndTime(getSystemTime());

			recycle_object_info_map_[obj_itr->first] = obj_itr->second;
			delete tracker_itr->second;

			traker_map_.erase(tracker_itr);
			object_info_map_.erase(obj_itr);
		}

	}
	void MultiTracker::Replace(cv::Mat & frame, cv::Rect & positionBox, size_t index)
	{

		std::map<size_t, KCFTracker*>::iterator tracker_itr = traker_map_.find(index);
		if (tracker_itr != traker_map_.end())
		{
			if (tracker_itr->second)
			{
				int index = tracker_itr->second->Index();
				delete tracker_itr->second;
				KCFTracker* tracker_ptr = new KCFTracker(HOG_, FIXEDWINDOW_, MULTISCALE_, LAB_, index);
				tracker_ptr->init(positionBox, frame);
				tracker_itr->second = tracker_ptr;
				//cv::Rect roi = subRect(positionBox, frame);
				/*std::vector<cv::Rect> roi_vec = subRect(positionBox, frame);
				  std::vector<cv::Mat> roi_mat_vec = { frame(roi_vec[0]).clone(), frame(roi_vec[1]).clone(), frame(roi_vec[2]).clone() };
				  object_info_map_[index]->AddToTemplate(roi_mat_vec);*/
			}
		}
	}
	std::vector<cv::Scalar> color_pool =
	{
		CV_RGB(255, 0, 0),
		CV_RGB(255, 128, 0),
		CV_RGB(0, 255, 0),
		CV_RGB(0, 255, 255),
		CV_RGB(128, 0, 255),
	};
	void MultiTracker::DrawTrace(cv::Mat& frame)
	{
		std::map<size_t, ObjectInfo*>::iterator obj_itr = object_info_map_.begin();
		std::map<size_t, ObjectInfo*>::iterator obj_end_itr = object_info_map_.end();
		for (; obj_itr != obj_end_itr; ++obj_itr)
		{
			if (obj_itr->second->CanBeRecycle() == true)
			{
				std::list<cv::Point>::iterator point_it = obj_itr->second->GetTrace().begin();
				if (obj_itr->second->GetTrace().size() > 20)
				{
					std::advance(point_it, obj_itr->second->GetTrace().size() - 20);
				}
				std::list<cv::Point>::iterator point_end_it = obj_itr->second->GetTrace().end();
				for (; point_it != point_end_it; ++point_it)
				{
					cv::circle(frame, *point_it, 0, color_pool[obj_itr->first % color_pool.size()], 2, 1);
				}
				cv::Rect banner(obj_itr->second->Box().x - 1, obj_itr->second->Box().y - 20, obj_itr->second->Box().width + 2, 20);
				banner &= cv::Rect(0, 0, frame.cols, frame.rows);
				frame(banner) = color_pool[obj_itr->first % color_pool.size()];
				cv::rectangle(frame, obj_itr->second->Box(), color_pool[obj_itr->first % color_pool.size()], 2, 1, 0);
				//cv::putText(frame, std::to_string(obj_itr->first).c_str(), cv::Point(obj_itr->second->Box().x, obj_itr->second->Box().y - 4), 1, 0.9, CV_RGB(0, 0, 0), 1);
				cv::putText(frame, obj_itr->second->AgeGender().c_str(), cv::Point(obj_itr->second->Box().x/* + (obj_itr->second->Box().width >> 1)*/, obj_itr->second->Box().y - 4), 1, 0.9, CV_RGB(0, 2, 15), 1);
				//cv::putText(frame, std::to_string(obj_itr->second->SynceOver()).c_str(), cv::Point(obj_itr->second->Box().x + 10, obj_itr->second->Box().y + 20), 2, 0.5, color_pool[obj_itr->first % color_pool.size()], 1);
				cv::putText(frame, std::to_string(obj_itr->second->CrossLine()).c_str(), cv::Point(obj_itr->second->Box().x + 10, obj_itr->second->Box().y + 20), 2, 0.5, color_pool[obj_itr->first % color_pool.size()], 1);
				cv::putText(frame, std::to_string(obj_itr->second->Life()).c_str(), cv::Point(obj_itr->second->Box().x + 10, obj_itr->second->Box().y + 30), 2, 0.4, color_pool[obj_itr->first % color_pool.size()], 1);
			}
		}
	}

	////////////////////////////////////////////////////////////
	//Draw UI in a high-quality image
	////////////////////////////////////////////////////////////
	void MultiTracker::DrawUI(cv::Mat& frame)
	{
		std::map<size_t, ObjectInfo*>::iterator obj_itr = object_info_map_.begin();
		std::map<size_t, ObjectInfo*>::iterator obj_end_itr = object_info_map_.end();
		for (; obj_itr != obj_end_itr; ++obj_itr)
		{
			if (obj_itr->second->CanBeRecycle() == true)
			{
				std::list<cv::Point>::iterator point_it = obj_itr->second->GetTrace().begin();
				if (obj_itr->second->GetTrace().size() > 20)
				{
					std::advance(point_it, obj_itr->second->GetTrace().size() - 20);
				}
				std::list<cv::Point>::iterator point_end_it = obj_itr->second->GetTrace().end();
				static float fractor_x = (float)frame.cols / g_detect_win.width; 
				static float fractor_y = (float)frame.rows / g_detect_win.height;
				for (; point_it != point_end_it; ++point_it)
				{
					cv::Point dot(int(point_it->x * fractor_x), int(point_it->y * fractor_y));
					cv::circle(frame, dot, 0, color_pool[obj_itr->first % color_pool.size()], 2, 1);
				}
				cv::Rect head_box;
				head_box.x = int(obj_itr->second->Box().x * fractor_x);
				head_box.y = int(obj_itr->second->Box().y * fractor_y);
				head_box.width = int(obj_itr->second->Box().width * fractor_x);
				head_box.height = int(obj_itr->second->Box().height * fractor_y);
				cv::Rect banner(head_box.x - 1, head_box.y - 20, head_box.width + 2, 20);
				banner &= cv::Rect(0, 0, frame.cols, frame.rows);
				frame(banner) = color_pool[obj_itr->first % color_pool.size()];
				cv::rectangle(frame, head_box, color_pool[obj_itr->first % color_pool.size()], 2, 1, 0);
				cv::putText(frame, std::to_string(obj_itr->first).c_str(), cv::Point(head_box.x, head_box.y + 15), 1, 0.9, CV_RGB(0, 0, 0), 1);
				cv::putText(frame, obj_itr->second->AgeGender().c_str(), cv::Point(head_box.x/* + (obj_itr->second->Box().width >> 1)*/, head_box.y - 4), 1, 0.9, CV_RGB(0, 2, 15), 1);
				static std::vector<std::string> sync_flag = {"syncing", "sync over"};
				cv::putText(frame, sync_flag[obj_itr->second->SynceOver()? 1 : 0].c_str(), cv::Point(head_box.x, head_box.y + 25), 2, 0.5, color_pool[obj_itr->first % color_pool.size()], 1);
				cv::putText(frame, std::to_string(obj_itr->second->CrossLine()).c_str(), cv::Point(head_box.x + 30, head_box.y + 10), 2, 0.5, color_pool[obj_itr->first % color_pool.size()], 1);
				cv::putText(frame, std::to_string(obj_itr->second->Life()).c_str(), cv::Point(head_box.x + 10, head_box.y + 35), 2, 0.4, color_pool[obj_itr->first % color_pool.size()], 1);
			}
		}
	}

	void MultiTracker::SetAllMatchFalse()
	{
		std::map<size_t, ObjectInfo*>::iterator obj_itr = object_info_map_.begin();
		std::map<size_t, ObjectInfo*>::iterator obj_end_itr = object_info_map_.end();
		for (; obj_itr != obj_end_itr; ++obj_itr)
		{
			obj_itr->second->SetMatchFalse();
		}
	}
	void MultiTracker::SetMatchTrue(size_t index)
	{
		std::map<size_t, ObjectInfo*>::iterator obj_itr = object_info_map_.find(index);
		//if(obj_itr != object_info_map_.end())
			obj_itr->second->SetMatchTrue();
	}
	void MultiTracker::SetBound(cv::Size size, cv::Rect bound)
	{
		bound_mask_ = cv::Mat(size, CV_8UC1);
		bound_mask_ = cv::Scalar::all(0);
		bound_mask_(bound) = cv::Scalar::all(255);
	}

	//void MultiTracker::PrintRecycle()
	/*std::map<size_t, ObjectInfo*>::iterator obj_itr = recycle_object_info_map_.begin();
	  std::map<size_t, ObjectInfo*>::iterator obj_end_itr = recycle_object_info_map_.end();
	  for (; obj_itr != obj_end_itr; ++obj_itr)
	  {
	  LOG(INFO) << *obj_itr->second;
	  }*/



	int MultiTracker::GetIndex_()
	{

		if (index_pool_set_.empty())
		{
			return ++key_max_;
		}
		else
		{
			int index = *(index_pool_set_.begin());
			index_pool_set_.erase(index_pool_set_.begin());
			return index;
		}
	}
}
